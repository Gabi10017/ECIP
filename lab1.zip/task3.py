import numpy as np
import matplotlib.pyplot as plt

T = 50
x = np.zeros(T)
x[0] = 0

for t in range(T - 1):
    x[t + 1] = x[t] + 1
    
np.random.seed(0)
noise = np.random.normal(loc=0, scale=2, size=T)
y= x + noise

W = 5
x_hat = np.zeros(T)
for t in range(T):
    start = max(0,t - W + 1)
    x_hat[t] = np.mean(y[start:t + 1])
    
plt.figure(figsize=(7, 4))
plt.plot(range(T), x, label='True state x(t)', color='blue')
plt.scatter(range(T), y, label='Observations y(t)', color='red', s=15, alpha=0.7)
plt.plot(range(T), x_hat, label='Estimated state (MA)', color='green')
plt.xlabel('t')
plt.ylabel('Value')
plt.title('True state, noisy observations, and moving average estimate')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()