import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# 1. Set seed for reproducibility
np.random.seed(42)

# 2. Generate Data
n_samples = 10000
# Gaussian (Normal) data: mean=0, std=1
gaussian_data = np.random.normal(loc=0, scale=1, size=n_samples)

# Uniform data: Using range [-3, 3] so it overlaps the normal distribution's typical spread
uniform_data = np.random.uniform(low=-3, high=3, size=n_samples)

# 3. Create the Plot
plt.figure(figsize=(10, 6))

# Plot empirical histograms (setting density=True for probability density)
plt.hist(gaussian_data, bins=50, alpha=0.6, density=True, color='blue', edgecolor='white', 
         label='Gaussian (Normal) $\mu=0, \sigma=1$')
plt.hist(uniform_data, bins=50, alpha=0.5, density=True, color='green', edgecolor='white', 
         label='Uniform [-3, 3]')

# 4. Add Theoretical PDFs (the dashed lines)
x_axis = np.linspace(-4, 4, 1000)

# Theoretical Gaussian PDF
gaussian_pdf = (1 / (np.sqrt(2 * np.pi))) * np.exp(-0.5 * x_axis**2)
plt.plot(x_axis, gaussian_pdf, color='darkblue', linewidth=2, linestyle='dashed', label='Gaussian PDF')

# Theoretical Uniform PDF
uniform_pdf = np.where((x_axis >= -3) & (x_axis <= 3), 1/6, 0)
plt.plot(x_axis, uniform_pdf, color='darkgreen', linewidth=2, linestyle='dashed', label='Uniform PDF')

# 5. Formatting and Saving
plt.title('Comparison: Gaussian vs. Uniform Distribution')
plt.xlabel('Value')
plt.ylabel('Density')
plt.legend()
plt.tight_layout()

# Save plot and show
plt.savefig('gaussian_vs_uniform.png')
plt.show()

# 6. Save