import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# 1. Set seed for reproducibility
np.random.seed(42)

# --- Define the System ---
# The underlying true value (what we want to know)
x_true = 10

# Generate 10,000 samples of noise
# We are using zero-mean Gaussian noise with a standard deviation of 1.5
n_samples = 10000
noise = np.random.normal(loc=0, scale=1.5, size=n_samples)

# --- Generate the Measurements ---
# The sensor observation is the true value PLUS the random noise
y_measurements = x_true + noise

# --- Plotting ---
plt.figure(figsize=(9, 5))

# Plot the distribution of the noisy measurements
plt.hist(y_measurements, bins=50, color='mediumpurple', edgecolor='white', density=True, 
         alpha=0.7, label='Measurements ($y$)')

# Add a distinct line showing exactly where the unobservable True Value is
plt.axvline(x=x_true, color='black', linestyle='dashed', linewidth=2.5, 
            label=f'True Value ($x={x_true}$)')

# Calculate the mean of our measurements to see how close it approximates the truth
sample_mean = np.mean(y_measurements)
plt.axvline(x=sample_mean, color='red', linestyle='dotted', linewidth=2.5, 
            label=f'Sample Mean ($\mu \approx {sample_mean:.2f}$)')

# Formatting the plot
plt.title('Measurement Distribution: True Value vs. Noisy Observations')
plt.xlabel('Measured Value')
plt.ylabel('Density')
plt.legend()
plt.tight_layout()

# Save the plot and display it
plt.savefig('measurement_simulation.png')
plt.show()

# Save the generated