import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# 1. Set the seed for reproducibility
# (This ensures you get the exact same "random" numbers every time you run it)
np.random.seed(42)

# 2. Generate 1000 random numbers from a standard normal distribution
data = np.random.randn(1000)

# 3. Set up the figure for the plots
plt.figure(figsize=(12, 5))

# --- Plot 1: Histogram ---
plt.subplot(1, 2, 1)
plt.hist(data, bins=30, color='skyblue', edgecolor='black')
plt.title('Histogram of 1000 Random Numbers')
plt.xlabel('Value')
plt.ylabel('Frequency')

# --- Plot 2: Sequence of Generated Values ---
plt.subplot(1, 2, 2)
plt.plot(data, color='orange', alpha=0.6)
plt.title('Sequence of Generated Values')
plt.xlabel('Index')
plt.ylabel('Value')

# Adjust layout to prevent overlap
plt.tight_layout()

# 4. Save and display the plots
plt.savefig('random_plots.png')
plt.show() 

# 5. Save the generated data to a CSV file
df = pd.DataFrame(data, columns=['random_value'])
df.to_csv('random_numbers.csv', index=False)
print("Plots saved to 'random_plots.png' and data saved to 'random_numbers.csv'.")
