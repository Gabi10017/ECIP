import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# 1. Set seed for reproducibility
np.random.seed(42)

# --- Define the Joint Distribution Parameters ---
mean = [0, 0] # Means of X and Y

# Define the Covariance Matrix:
# [[ Variance of X,   Covariance(X,Y) ],
#  [ Covariance(X,Y), Variance of Y   ]]
# We'll set the variance of both to 1.0, and a strong positive theoretical covariance
theoretical_cov = 0.85
cov_matrix = [[1.0, theoretical_cov], 
              [theoretical_cov, 1.0]]

# 2. Generate 1000 correlated samples using a Multivariate Normal Distribution
data = np.random.multivariate_normal(mean, cov_matrix, 1000)
x = data[:, 0]
y = data[:, 1]

# 3. Compute empirical sample covariance matrix
# np.cov returns the full 2x2 covariance matrix. We extract the off-diagonal element [0, 1]
sample_cov_matrix = np.cov(x, y)
sample_cov = sample_cov_matrix[0, 1]

print(f"Theoretical Covariance: {theoretical_cov}")
print(f"Sample Covariance: {sample_cov:.5f}")

# --- 4. Plotting the Scatter Plot ---
plt.figure(figsize=(8, 6))

# Plot the raw data points
plt.scatter(x, y, alpha=0.6, color='teal', edgecolor='white')

# Calculate and add a simple linear trendline (Line of Best Fit)
m, b = np.polyfit(x, y, 1)
plt.plot(x, m*x + b, color='red', linewidth=2, linestyle='dashed', label='Trendline')

# Formatting the plot
plt.title('Scatter Plot of Correlated Random Variables ($X$ and $Y$)')
plt.xlabel('Variable $X$')
plt.ylabel('Variable $Y$')
plt.axhline(0, color='black', linewidth=0.5)
plt.axvline(0, color='black', linewidth=0.5)
plt.grid(True, linestyle='--', alpha=0.5)
plt.legend()
plt.tight_layout()

# Save plot and display
plt.savefig('correlated_variables.png')
plt.show()

# 5. Save the generated data to a CSV file
df = pd.DataFrame({'X': x, 'Y': y})
df.to_csv('correlated_data.csv', index=False)