import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# 1. Set seed for reproducibility
np.random.seed(42)

# 2. Define Parameters
n_samples = 10000
mean = 0

# Define variances and calculate corresponding standard deviations
variances = [0.5, 1.0, 5.0]
stds = np.sqrt(variances) 

# 3. Generate Gaussian Noise Data
data_low = np.random.normal(loc=mean, scale=stds[0], size=n_samples)
data_med = np.random.normal(loc=mean, scale=stds[1], size=n_samples)
data_high = np.random.normal(loc=mean, scale=stds[2], size=n_samples)

# 4. Create the Plot
plt.figure(figsize=(10, 6))

# Plot histograms with density=True to compare probability density
plt.hist(data_low, bins=60, alpha=0.7, density=True, color='dodgerblue', edgecolor='white', 
         label=f'Low Variance ($\sigma^2={variances[0]}$)')
plt.hist(data_med, bins=60, alpha=0.7, density=True, color='mediumseagreen', edgecolor='white', 
         label=f'Medium Variance ($\sigma^2={variances[1]}$)')
plt.hist(data_high, bins=60, alpha=0.6, density=True, color='coral', edgecolor='white', 
         label=f'High Variance ($\sigma^2={variances[2]}$)')

# Formatting
plt.title('Gaussian Noise: Comparing Different Variances')
plt.xlabel('Value')
plt.ylabel('Probability Density')
plt.xlim(-8, 8)
plt.legend()
plt.tight_layout()

# 5. Save and Display
plt.savefig('gaussian_variances.png')
plt.show()

# 6. Save Data to CSV
df = pd.DataFrame({'var_0.5': data_low, 'var_1.0': data_med, 'var_5.0': data_high})
df.to_csv('gaussian_noise_variances.csv', index=False)