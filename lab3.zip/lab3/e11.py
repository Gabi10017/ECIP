import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# 1. Set seed for reproducibility
np.random.seed(42)

# --- Define the True Probabilities ---
n_samples = 10000
p_B_true = 0.40             # P(B): 40% chance of Event B happening
p_A_given_B_true = 0.80     # P(A|B): 80% chance of A if B happens
p_A_given_not_B_true = 0.25 # P(A|~B): 25% chance of A if B does NOT happen

# --- 2. Simulate the Events ---
# Generate Event B (True roughly 40% of the time)
B = np.random.rand(n_samples) < p_B_true

# Initialize Event A array
A = np.zeros(n_samples, dtype=bool)

# Generate Event A conditionally based on B's outcome
# If B is true, apply the 80% probability
A[B] = np.random.rand(np.sum(B)) < p_A_given_B_true
# If B is false, apply the 25% probability
A[~B] = np.random.rand(np.sum(~B)) < p_A_given_not_B_true

# --- 3. Estimate Probabilities from the Data ---
# Calculate P(B) -> Total True B's / Total Samples
p_B_est = np.mean(B)

# Calculate P(A intersection B) -> Times BOTH A and B are True / Total Samples
p_A_and_B_est = np.mean(A & B)

# Calculate P(A|B) using the formula: P(A and B) / P(B)
# (Alternatively, you can just do: np.mean(A[B]))
p_A_given_B_est = p_A_and_B_est / p_B_est

print(f"Empirical P(B): {p_B_est:.4f} (True: {p_B_true})")
print(f"Empirical P(A and B): {p_A_and_B_est:.4f}")
print(f"Estimated P(A|B): {p_A_given_B_est:.4f} (True: {p_A_given_B_true})")

# --- 4. Plotting the Frequencies ---
categories = ['A and B\n(Intersection)', 'A and Not B', 'Not A and B', 'Neither\n(Not A, Not B)']
counts = [
    np.sum(A & B),
    np.sum(A & ~B),
    np.sum(~A & B),
    np.sum(~A & ~B)
]

# Convert to percentages for plotting
percentages = [c / n_samples * 100 for c in counts]

plt.figure(figsize=(9, 6))
bars = plt.bar(categories, percentages, 
               color=['mediumorchid', 'skyblue', 'lightcoral', 'lightgray'], 
               edgecolor='black')

# Annotate bars with their percentage values
for bar in bars:
    yval = bar.get_height()
    plt.text(bar.get_x() + bar.get_width()/2, yval + 1, f'{yval:.1f}%', 
             ha='center', va='bottom', fontweight='bold')

plt.title('Distribution of Simulated Events A and B')
plt.ylabel('Percentage of Total Samples (%)')
plt.ylim(0, max(percentages) + 10)
plt.tight_layout()

# Save plot and display
plt.savefig('conditional_probability.png')
plt.show()

# --- 5. Save Data to CSV ---
df = pd.DataFrame({'Event_A': A, 'Event_B': B})
df.to_csv('simulated_events.csv', index=False)