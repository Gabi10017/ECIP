import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# 1. Set seed for reproducibility
np.random.seed(42)

# --- Define the System ---
x_true = 10
n_samples = 10000

# Generate Noisy Measurements (y = x + noise)
noise = np.random.normal(loc=0, scale=1.5, size=n_samples)
y_measurements = x_true + noise

# --- Compute the Final Estimate ---
# The estimate is the mean of all our measurements
x_estimate = np.mean(y_measurements)

# --- Compute Final Estimation Error ---
estimation_error = x_estimate - x_true

print(f"True Value: {x_true}")
print(f"Estimated Value: {x_estimate:.5f}")
print(f"Estimation Error: {estimation_error:.5f}")

# --- Analyze Error Over Time (Running Mean) ---
# np.cumsum gives a running sum, we divide by an array of [1, 2, ..., N] to get the running mean
running_mean = np.cumsum(y_measurements) / np.arange(1, n_samples + 1)
# The running error is the running mean minus the true value
running_error = running_mean - x_true

# --- Plotting the Convergence ---
plt.figure(figsize=(12, 5))

# Plot 1: How the running estimate approaches the true value
plt.subplot(1, 2, 1)
plt.plot(np.arange(1, n_samples + 1), running_mean, color='dodgerblue', label='Running Estimate ($\hat{x}$)')
plt.axhline(y=x_true, color='black', linestyle='dashed', linewidth=2, label='True Value ($x=10$)')
plt.title('Convergence of Estimate to True Value')
plt.xlabel('Number of Measurements ($N$)')
plt.ylabel('Estimated Value')
plt.xscale('log') # Use a log scale to better see the high variance at low N
plt.legend()

# Plot 2: How the estimation error approaches zero
plt.subplot(1, 2, 2)
plt.plot(np.arange(1, n_samples + 1), running_error, color='crimson', label='Estimation Error ($\hat{x} - x$)')
plt.axhline(y=0, color='black', linestyle='dashed', linewidth=2, label='Zero Error')
plt.title('Estimation Error vs. Sample Size')
plt.xlabel('Number of Measurements ($N$)')
plt.ylabel('Error')
plt.xscale('log')
plt.legend()

# Save the plot and display it
plt.tight_layout()
plt.savefig('estimation_error.png')