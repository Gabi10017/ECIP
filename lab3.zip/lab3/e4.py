import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# 1. Set seed for reproducibility
np.random.seed(42)

# --- Compute Variance of Uniform(0,1) Data ---
# Generate the data
x_uniform = np.random.uniform(0, 1, 10000)

# Calculate Sample Variance (using ddof=1 for an unbiased estimator of population variance)
sample_variance = np.var(x_uniform, ddof=1)

# Calculate Theoretical Variance: (b - a)^2 / 12
theoretical_variance = ((1 - 0)**2) / 12

print(f"Uniform Data Sample Variance: {sample_variance:.5f}")
print(f"Uniform Data Theoretical Variance: {theoretical_variance:.5f}")

# --- Compare Datasets with Different Variances ---
# Dataset A: Normal distribution, Mean = 0, Standard Deviation = 1 (Variance = 1)
data_low_var = np.random.normal(loc=0, scale=1, size=10000)

# Dataset B: Normal distribution, Mean = 0, Standard Deviation = 3 (Variance = 9)
data_high_var = np.random.normal(loc=0, scale=3, size=10000)

# --- Plotting the Comparison ---
plt.figure(figsize=(10, 5))

# Plot low variance data
plt.hist(data_low_var, bins=50, alpha=0.7, density=True, 
         label='Low Variance ($\sigma^2 \approx 1$)', color='skyblue', edgecolor='white')

# Plot high variance data
plt.hist(data_high_var, bins=50, alpha=0.5, density=True, 
         label='High Variance ($\sigma^2 \approx 9$)', color='orange', edgecolor='white')

# Add a line to mark the shared mean of 0
plt.axvline(x=0, color='red', linestyle='dashed', linewidth=2, label='Shared Mean (0)')

# Formatting the plot
plt.title('Comparing Data Spread: Low vs. High Variance')
plt.xlabel('Value')
plt.ylabel('Density')
plt.legend()
plt.tight_layout()

# Save the plot and datasets
plt.savefig('variance_comparison.png')
plt.show()

# Save comparison datasets to a CSV file
df = pd.DataFrame({'low_variance': data_low_var, 'high_variance': data_high_var})
df.to_csv('variance_datasets.csv', index=False)
