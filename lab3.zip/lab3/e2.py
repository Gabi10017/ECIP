import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# 1. Set seed for reproducibility
np.random.seed(42)

# 2. Simulate 10,000 values from a Uniform(0,1) distribution
x = np.random.uniform(0, 1, 10000)

# 3. Set up the figure
plt.figure(figsize=(8, 5))

# Plot the histogram (Empirical Distribution)
# Setting density=True ensures the y-axis represents probability density rather than raw counts
plt.hist(x, bins=50, color='lightgreen', edgecolor='black', density=True, label='Empirical Data')

# Add the theoretical Probability Density Function (PDF) line
# For a Uniform(0,1) distribution, the density is exactly 1 between 0 and 1
plt.plot([0, 1], [1, 1], color='red', linestyle='dashed', linewidth=2, label='Theoretical PDF')

# Add labels, title, and legend
plt.title('Histogram of $X \sim Uniform(0,1)$')
plt.xlabel('Value')
plt.ylabel('Density')
plt.legend()
plt.tight_layout()

# 4. Save and display the plot
plt.savefig('uniform_histogram.png')
plt.show()

# 5. Save the generated data to a CSV file
df = pd.DataFrame(x, columns=['value'])
df.to_csv('uniform_data.csv', index=False)
print("Simulation complete. Data saved to 'uniform_data.csv'.")