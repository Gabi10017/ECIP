import numpy as np

# 1. Set seed for reproducibility
np.random.seed(42)

# 2. Simulate 10,000 values from a Uniform(0,1) distribution
x = np.random.uniform(0, 1, 10000)

# 3. Compute the Sample Mean
sample_mean = np.mean(x)

# 4. Define the Theoretical Mean for Uniform(0,1)
# Formula: (a + b) / 2
theoretical_mean = (0 + 1) / 2

# 5. Output the results for comparison
print(f"Sample Mean: {sample_mean:.5f}")
print(f"Theoretical Mean: {theoretical_mean:.5f}")

# Optional: Calculate the absolute difference
difference = abs(theoretical_mean - sample_mean)
print(f"Difference: {difference:.5f}")