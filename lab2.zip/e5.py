import numpy as np
import matplotlib.pyplot as plt

# Define the highly sensitive growth rate and the 4 starting populations
r = 4
initial_populations = [0.1, 0.5, 1.0, 2.0]
iterations = 15  # Number of generations to track

# Create a 2x2 grid for our subplots
fig, axes = plt.subplots(2, 2, figsize=(12, 8))
axes = axes.flatten()

for idx, x0 in enumerate(initial_populations):
    x = np.zeros(iterations)
    x[0] = x0
    
    for i in range(1, iterations):
        # The discrete logistic equation
        val = r * x[i-1] * (1 - x[i-1])
        
        # Stop plotting the math if it drops below -10 so the graph stays readable
        if val < -10:
            x[i] = np.nan
        else:
            x[i] = val
            
    # Plotting formatting for each subplot
    axes[idx].plot(range(iterations), x, marker='o', linestyle='-', color='b')
    axes[idx].set_title(f'Initial Population = {x0} (r = 4)')
    axes[idx].set_xlabel('Generation')
    axes[idx].set_ylabel('Population Size')
    
    # Draw a faint red dashed line to represent 0 (extinction baseline)
    axes[idx].axhline(y=0, color='r', linestyle='--', alpha=0.5) 
    axes[idx].grid(True)

# Adjust the layout and display the plot
plt.tight_layout()
plt.show()