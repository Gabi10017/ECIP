report_content = """Exercise 1: Logistic Growth (r = 0.9)
Model: P(t) = K / (1 + ((K - P0) / P0) * e^(-rt))
With r = 0.9, the population follows a classic S-shaped (sigmoid) curve:
* Exponential Phase: Rapid early growth due to abundant resources.
* Transitional Phase: Growth slows as the population approaches carrying capacity (K).
* Plateau Phase: Growth stops. The population permanently stabilizes at K.

---

Exercise 2: The Onset of Chaos
Model (Discrete Map): x_{n+1} = r * x_n * (1 - x_n)
* 1 < r < 3: Smooth stabilization.
* 3 <= r < 3.56995: Oscillations (period-doubling).
* r approx 3.56995: The exact onset of mathematical chaos.
* r > 3.56995: Unpredictable, chaotic fluctuations.

---

Exercise 3: Dynamics of Specific r Values
Simulating the array [2, 2.5, 1, 1.2, 3.1, 0.5, 4, 4.4, 3, 2.9, 2.8, 1.9, 1.5, 1.4, 7, 3.8, 8]:
* Extinction (r = 0.5, 1): Population drops to 0.
* Stabilization (r = 1.2 to 2.9): Settles smoothly at a fixed carrying capacity.
* Oscillation (r = 3, 3.1): Bounces continuously between high and low values.
* Chaos (r = 3.8, 4): Wild, non-repeating fluctuations.
* Collapse (r = 4.4, 7, 8): Massive overshoot causing immediate mathematical divergence (extinction).

---

Exercise 4: 17-Year Sequence
Using the previous array as sequential yearly r values:
* Year 8 (r = 4.4): The population severely overshoots the carrying capacity.
* Year 9: The overshoot forces the equation into negative numbers, representing complete ecological collapse and extinction.
* Year 17: Biologically, the population is 0 (extinct since Year 9). Mathematically, the broken equation yields an impossible -8.89 x 10^67.

---

Exercise 5: Impact of Initial Population Size (r = 4)
Testing different starting population proportions with a highly sensitive growth rate of r = 4 yields distinct outcomes:
*⁠Start at 0.1: The population survives but enters a state of permanent, unpredictable chaos.
*⁠Start at 0.5: The population hits 1.0 in the first generation, then immediately crashes to 0 (extinction) in the second.
*⁠Start at 1.0: Starting exactly at carrying capacity causes an immediate crash to 0 in the next generation.
*⁠Start at 2: Starting at 200% capacity causes the math to instantly dive into negative numbers (immediate biological extinction).

---

Exercise 6: Markov Chain Population Dynamics

Simulation: A 15-step discrete model where the growth rate (r) is dictated by a 3-state Markov machine. 
* State A (r = 1.5)
*⁠State B (r = 2.0)
* State C (r = 3.3)
Analysis: Starting from a population of 0.5, the population size dynamically shifts each step based on the transition probabilities of the machine. Because the system continuously switches between growth factors that are all structurally sound (between 1.5 and 3.3), the population constantly fluctuates without ever settling into a permanent equilibrium or risking extinction.

---

Exercise 7: Modified Markov Chain (Weight B = 0.5)

Survival after 15 steps: Yes, but severely diminished (Final Population ≈ 0.0577).
Analysis: Changing State B to r=0.5 introduces an extinction phase. The population crashes every time State B occurs in the sequence. While States A and C allow some brief growth, the repeated crashes prevent full recovery, keeping the overall population size near zero.

"""


# Generate the text file
file_name = "Condensed_Population_Report.txt"
with open(file_name, "w") as file:
    file.write(report_content)

print(f"Success! Your file has been generated and saved as '{file_name}'.")