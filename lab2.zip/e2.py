import numpy as np
import matplotlib.pyplot as plt


r_values = np.linspace(2.5, 4.0, 10000)
iterations = 1000  
last = 100         


x = 1e-5 * np.ones_like(r_values)

plt.figure(figsize=(10, 7))


for i in range(iterations):
   
    x = r_values * x * (1 - x)
    
  
    if i >= (iterations - last):
        plt.plot(r_values, x, ',k', alpha=0.25) 


plt.xlim(2.5, 4.0)
plt.title("Bifurcation Diagram: Onset of Chaos in Population Growth")
plt.xlabel("Growth Rate (r)")
plt.ylabel("Population Proportion (x)")

# Draw a red line where chaos begins
plt.axvline(x=3.56995, color='red', linestyle='--', label='Onset of Chaos (r ≈ 3.57)')
plt.legend()

plt.tight_layout()
plt.savefig('bifurcation_diagram.png', dpi=300)

