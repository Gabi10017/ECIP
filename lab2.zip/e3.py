import numpy as np
import matplotlib.pyplot as plt

# Your requested r values
r_values = [2, 2.5, 1, 1.2, 3.1, 0.5, 4, 4.4, 3, 2.9, 2.8, 1.9, 1.5, 1.4, 7, 3.8, 8]
iterations = 50  # Number of generations to simulate

# Create a 5x4 grid of subplots
fig, axes = plt.subplots(5, 4, figsize=(16, 18))
axes = axes.flatten()

for idx, r in enumerate(r_values):
    x = np.zeros(iterations)
    x[0] = 0.1  # Starting with a small initial population proportion
    
    for i in range(1, iterations):
        # The discrete logistic equation
        val = r * x[i-1] * (1 - x[i-1])
        
        # Stop plotting if the math explodes (r > 4)
        if abs(val) > 2: 
            x[i] = np.nan 
        else:
            x[i] = val
            
    # Plot the specific r value on its assigned subplot
    ax = axes[idx]
    ax.plot(range(iterations), x, 'b-', marker='.', markersize=4)
    ax.set_title(f'r = {r}')
    ax.set_xlabel('Generation')
    ax.set_ylabel('Population (x)')
    ax.grid(True)

# Remove any unused subplots (since 17 < 20)
for i in range(len(r_values), len(axes)):
    fig.delaxes(axes[i])

# Format and show the plot
plt.tight_layout()
plt.show()