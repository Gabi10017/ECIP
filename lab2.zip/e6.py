import numpy as np
import matplotlib.pyplot as plt


states = ['A', 'B', 'C']
weights = {'A': 1.5, 'B': 2.0, 'C': 3.3}
initial_population = 0.5
num_steps = 15


transitions = {
    'A': [0.0, 0.4, 0.6], 
    'B': [0.5, 0.5, 0.0],  
    'C': [0.2, 0.2, 0.6]   
}


history_pop = [initial_population]
history_state = []
history_r = []

current_state = 'A'
current_population = initial_population

for step in range(1, num_steps + 1):
 
    current_probs = transitions[current_state]
    next_state = np.random.choice(states, p=current_probs)
 
    r = weights[next_state]
    new_population = r * current_population * (1 - current_population)
 
    history_pop.append(new_population)
    history_state.append(next_state)
    history_r.append(r)

    current_state = next_state
    current_population = new_population

fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 8), sharex=True)

ax1.plot(range(num_steps + 1), history_pop, 'b-o', linewidth=2)
ax1.set_ylabel('Population Size (P)')
ax1.set_title('Markov Chain Population Dynamics')
ax1.grid(True)

steps_r = range(1, num_steps + 1)
ax2.step(steps_r, history_r, 'r-o', where='mid', linewidth=2)
ax2.set_ylabel('Growth Factor (r)')
ax2.set_xlabel('Step')

ax2.set_yticks([1.5, 2.0, 3.3])
ax2.set_yticklabels(['State A (r=1.5)', 'State B (r=2.0)', 'State C (r=3.3)'])
ax2.set_xticks(range(num_steps + 1))
ax2.grid(True, axis='y', linestyle='--')

plt.tight_layout()

plt.savefig('markov_population_plot.png', dpi=300)
plt.show()

print(f"Simulation complete! Final Population Size: {current_population:.4f}")